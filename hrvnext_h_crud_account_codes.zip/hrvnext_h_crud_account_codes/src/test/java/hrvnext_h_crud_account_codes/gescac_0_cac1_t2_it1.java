package hrvnext_h_crud_account_codes;


import org.testng.annotations.Test;
import org.testng.Assert;
import static org.testng.Assert.fail;

import org.openqa.selenium.*;
import hrvnext_h_crud_account_codes.login;

public class gescac_0_cac1_t2_it1 extends login {
	
	  
  @Test ( priority = 2 )
  public void testGESCAC0CAC1T2IT1() throws Exception {
   
Thread.sleep(500);
    String rowInd = "1";
    Thread.sleep(500);
    System.out.println("Check value in field CPT Is Modifier");
    try {
      Assert.assertEquals(driver.findElement(By.xpath("(//input[@data-s-x3name='CAC1_CPT'])[" + rowInd + "]")).getAttribute("value"), "Modifier");
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    for (int second = 0;; second++) {
    	if (second >= 60) fail("timeout");
    	try { if ("0".equals(driver.findElement(By.xpath("//aside[@id='s-site-quality']")).getAttribute("data-s-request-count"))) break; } catch (Exception e) {}
    	Thread.sleep(1000);
    }

    for (int second = 0;; second++) {
    	if (second >= 60) fail("timeout");
    	try { if ("0".equals(driver.findElement(By.xpath("//aside[@id='s-site-quality']")).getAttribute("data-s-uilock"))) break; } catch (Exception e) {}
    	Thread.sleep(1000);
    }

    System.out.println("Check value in field ADESIG Is Payroll MO");
    try {
      Assert.assertEquals(driver.findElement(By.xpath("(//input[@data-s-x3name='CAC1_ADESIG'])[" + rowInd + "]")).getAttribute("value"), "Payroll MO");
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    for (int second = 0;; second++) {
    	if (second >= 60) fail("timeout");
    	try { if ("0".equals(driver.findElement(By.xpath("//aside[@id='s-site-quality']")).getAttribute("data-s-request-count"))) break; } catch (Exception e) {}
    	Thread.sleep(1000);
    }

    for (int second = 0;; second++) {
    	if (second >= 60) fail("timeout");
    	try { if ("0".equals(driver.findElement(By.xpath("//aside[@id='s-site-quality']")).getAttribute("data-s-uilock"))) break; } catch (Exception e) {}
    	Thread.sleep(1000);
    }

    System.out.println("Check value in field OBL Is No");
    try {
      Assert.assertEquals(driver.findElement(By.xpath("(//input[@data-s-x3name='CAC1_OBL'])[" + rowInd + "]")).getAttribute("value"), "No");
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    for (int second = 0;; second++) {
    	if (second >= 60) fail("timeout");
    	try { if ("0".equals(driver.findElement(By.xpath("//aside[@id='s-site-quality']")).getAttribute("data-s-request-count"))) break; } catch (Exception e) {}
    	Thread.sleep(1000);
    }

    for (int second = 0;; second++) {
    	if (second >= 60) fail("timeout");
    	try { if ("0".equals(driver.findElement(By.xpath("//aside[@id='s-site-quality']")).getAttribute("data-s-uilock"))) break; } catch (Exception e) {}
    	Thread.sleep(1000);
    }

  }


}
